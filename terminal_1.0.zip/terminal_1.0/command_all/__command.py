import os
import importlib

def check(r):
    if r != 0:
        print('ERROR')

def if_user(tmp, root):
    """
        Executes user-level command based on input.

        Parameters:
            - tmp (list): List of command and arguments split from user input.
    """

    if tmp:
        try:
            # Attempt to import and initialize module based on user command
            mod = importlib.import_module(f'command_all.{tmp[0].lower()}', package='__init__')
            result = mod.__init__(root, tmp)
            check(result)
            del mod # Initialize module with user-level privilege (2)
        except ModuleNotFoundError:
            print(f'no \'{tmp[0]}\' command')
#		except:
#			print(f'this command \'{tmp[0]}\' is not fixed')		


def for_command(tmp):
    """
        Splits input command string into a list of words.

        Parameters:
            - tmp (str): Input command string.

        Returns:
            - list: List of words from the input command string.
    """ 
    tmp2 = []

    for i in tmp.split():
        if i:
            tmp2.append(i)
    return tmp2
 

class input_all:
    """
        Class to handle input commands and execute corresponding actions.
    """

    def per_init(self, command, root):
        """
            Initializes InputAll instance with a command.

            Parameters:
                - command (str): Input command string.
        """
        self.command = command
        self.tmp = for_command(str(self.command))
        self.root = root

    def command_user(self, command, root):
        """
            Executes root-level command based on the stored command string.
        """
    
        self.per_init(command, root)
        if_user(self.tmp, self.root)
