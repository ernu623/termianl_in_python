from .__passwd import*

def re():
	login()

def login():
	"""
        if the login is 'normal user' 
        and the password is 'passwd user' the sapal returns 1,
        and if the login is 'user_root' and the password is 'passwd_root' then it returns 2,
        and if neither one nor the other then it returns -1
	"""

	user = str(input('login: '))
   
	passwd = str(input('password: '))
       
	tmp = passwd_login()
   
	if user == tmp.user_normal:
		if passwd == tmp.passwd_user:
			return 1
		else:
			return 3
	elif user == tmp.user_root:
		if passwd == tmp.passwd_root:
			return 2
		else:
			return 3
	else:
		return 3

