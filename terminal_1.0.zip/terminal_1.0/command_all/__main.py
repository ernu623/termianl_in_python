from .__login_main import* # Importing the login function from the __login_main module 
from .__command import* # Importing the command_user and command_root functions from the __command module 


class login_all(input_all):
    def input_user(self):
        # Infinite loop for user command input
        while True:
            self.command = str(input('# ' if self.root == 2 else '$ ')) # Input command and strip extra spaces
            if not self.command.strip(): 
                self.input_user()
            elif self.command[0:2] == '__':
                print(f'no \'{self.command}\' command') # Error message if the command starts with '__'
                self.input_user()
            
            self.command_user(self.command, self.root)  # Call the command_user function with the input command


    def init(self, result):
        self.root = result
        if self.root != 3:
            self.input_user()
        else:
            print('is possword and login found')

class start_main(login_all):
    def __init__(self):
        self.init(login()) # Call the login function and pass its result to init

def main():
    start_main() # Create an instance of StartMain and start the process

