

class passwd_login():
	"""
	root user:
		login: root
		password: 2222

	normal user:
		login: user
		password: 1111
	"""
	def __init__(self):
		self.user_normal = 'user'
		self.passwd_user = '1111'
		self.user_root = 'root'
		self.passwd_root = '2222'
		super().__init__()

def main():
	passwd_login()


