
def __init__(*argv):
	print(argv)
	return 0
