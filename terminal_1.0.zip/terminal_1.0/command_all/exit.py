
def __init__(*argv):
	"""
		log in from programs	
	"""
	exit()
	return 0

