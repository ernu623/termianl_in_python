
def __init__(*argv):
	"""
		test
	"""
	print('ok')

	return 0
