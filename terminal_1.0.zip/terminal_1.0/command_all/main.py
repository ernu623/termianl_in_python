def __init__(*argv):
	"""
		test
	"""
	print('test')
	return 0
