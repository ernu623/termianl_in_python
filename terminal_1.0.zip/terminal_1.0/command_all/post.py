def arg(argv):
    return argv[1][1:]

def __init__(*argv):
    '''
        this is 
    '''
    import importlib
    result = list(str(argv[0])) + arg(argv)
    try:
        mod = importlib.import_module(f'command_all.{argv[1][1]}', package='__init__')
        print(mod.__init__(result))
        del mod
    except FileNotFoundError:
        print('no file')
    except:
        print('post [command]')
        return 1
    return 0

    
