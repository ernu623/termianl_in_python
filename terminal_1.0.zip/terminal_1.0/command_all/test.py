

def __init__(*argv):
	"""
		test
	"""
	print('all ok')
	print('test #1')
	return 0
