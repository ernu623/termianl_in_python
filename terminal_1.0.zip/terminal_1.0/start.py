from command_all.__main import main

def start():
	main()

if __name__ == '__main__':
	start()
